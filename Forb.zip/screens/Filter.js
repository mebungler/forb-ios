import React, { Component } from "react";
import {
	StyleSheet,
	View,
	ScrollView,
	TouchableWithoutFeedback,
	Text,
	Dimensions
} from "react-native";
import { CheckBox } from "react-native-elements";
import Icon from "../services/IconService";
import Colors from "../constants/Colors";
import Header from "../components/Header";
import RoundButton from "../components/RoundButton";
import api from "../api/api";
import DefaultPicker from "../components/DefaultPicker";
import RoundInput from "../components/RoundInput";

class Filter extends Component {
	componentDidMount() {
		let categoryId = this.props.navigation.getParam("categoryId");
		api.category.filters(categoryId).then(res => {
			this.setState({ ...this.state, filters: res.data.data });
		});
	}
	state = {
		withPhoto: false,
		searchInText: false,
		price: 0,
		tile: this.props.navigation.getParam("isTile"),
		filters: [],
		values: {}
	};
	changeOrientation = tile => {
		let changeOrientation = this.props.navigation.getParam(
			"changeOrientation"
		);
		this.setState({ ...this.state, tile });
		changeOrientation(tile);
	};
	render() {
		let {
			withPhoto,
			searchInText,
			price,
			tile,
			filters,
			values
		} = this.state;
		let { changeOrientation } = this;
		return (
			<View style={{ flex: 1 }}>
				<Header back name="Фильтр" />
				<ScrollView style={{ padding: 15 }}>
					<CheckBox
						checked={searchInText}
						containerStyle={{
							backgroundColor: "transparent",
							borderWidth: 0,
							padding: 0,
							margin: 0,
							justifyContent: "flex-start",
							paddingBottom: 15
						}}
						iconType="font-awesome"
						checkedIcon="check-square-o"
						title="Искать в тексте объявлений"
						checkedColor={Colors.pink}
						uncheckedIcon="square-o"
						textStyle={{
							color: Colors.black,
							fontWeight: "400"
						}}
						onPress={() =>
							this.setState({
								...this.state,
								searchInText: !this.state.searchInText
							})
						}
					/>
					<CheckBox
						checked={withPhoto}
						containerStyle={{
							backgroundColor: "transparent",
							borderWidth: 0,
							padding: 0,
							margin: 0,
							justifyContent: "flex-start"
						}}
						iconType="font-awesome"
						checkedIcon="check-square-o"
						title="Только с фото"
						checkedColor={Colors.pink}
						uncheckedIcon="square-o"
						textStyle={{
							color: Colors.black,
							fontWeight: "400"
						}}
						onPress={() =>
							this.setState({
								...this.state,
								withPhoto: !this.state.withPhoto
							})
						}
					/>
					<View style={{ alignItems: "center", paddingTop: 15 }}>
						{filters &&
							filters.map((el, index) => {
								switch (el.type) {
									case "input":
										return (
											<RoundInput
												onTextChange={(key, val) =>
													this.setState({
														...this.setState,
														values: {
															...this.state
																.values,
															[key]: val
														}
													})
												}
												style={{
													borderColor: Colors.gray,
													borderWidth: 1,
													borderRadius: 30,
													width:
														Dimensions.get("window")
															.width - 60,
													paddingLeft: 30
												}}
												main
												placeholder={el.name}
												name={`${el.id}`}
											/>
										);
										break;
									case "select":
										return (
											<DefaultPicker
												rightIcon={() => (
													<Icon
														name="chevrondown"
														size={10}
														color={Colors.pink}
													/>
												)}
												selectedValue={
													values[el.id]
														? values[el.id]
														: ""
												}
												placeholder={el.name}
												data={
													el.childs
														? el.childs.map(e => ({
																label: e.name,
																value: e.value
														  }))
														: []
												}
												onValueChange={(val, i) => {
													let {
														values: f
													} = this.state;
													f[el.id] = val;
													this.setState({
														...this.state,
														values: f
													});
													console.warn(
														this.state.values
													);
												}}
												style={{
													backgroundColor:
														Colors.white,
													borderColor: Colors.gray,
													borderWidth: 1,
													shadowColor: Colors.gray,
													shadowRadius: 2,
													shadowOffset: {
														width: 0,
														height: 0
													},
													borderRadius: 30
												}}
												small
											/>
										);
										break;
									default:
										return null;
										break;
								}
							})}
					</View>

					<View
						style={{
							flexDirection: "row",
							justifyContent: "space-evenly",
							padding: 15
						}}
					>
						<TouchableWithoutFeedback
							onPress={() => changeOrientation(true)}
						>
							<View style={{ alignItems: "center" }}>
								<Icon
									name="tile"
									size={30}
									color={tile ? Colors.blue : Colors.darkGray}
								/>
								<Text
									style={{
										color: tile
											? Colors.blue
											: Colors.darkGray,
										fontSize: 20
									}}
								>
									Список
								</Text>
							</View>
						</TouchableWithoutFeedback>
						<TouchableWithoutFeedback
							onPress={() => changeOrientation(false)}
						>
							<View style={{ alignItems: "center" }}>
								<Icon
									name="list"
									color={
										!tile ? Colors.blue : Colors.darkGray
									}
									size={30}
								/>
								<Text
									style={{
										color: !tile
											? Colors.blue
											: Colors.darkGray,
										fontSize: 20
									}}
								>
									Плитка
								</Text>
							</View>
						</TouchableWithoutFeedback>
					</View>
				</ScrollView>
				<View style={{ padding: 15, alignItems: "center" }}>
					<RoundButton
						text="Показать объявлений"
						color={Colors.blue}
						fill
						mediumSize
						big
						animated
						onPress={() => {
							this.props.navigation.goBack();
						}}
					/>
				</View>
			</View>
		);
	}
}

export default Filter;
