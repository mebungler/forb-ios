export default {
	blue: "#5cc6d0",
	lightBlue: "#d1f6f9",
	darkBlue: "#408a91",
	pink: "#C35ED6",
	black: "#414b4e",
	lightGray: "#f8f9fc",
	gray: "#dbdfe9",
	darkGray: "#919191",
	white: "#fff"
};
