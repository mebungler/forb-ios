import React from "react";

export default {
	Product: true,
	Chat: true
};
